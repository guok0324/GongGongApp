
export const hostUrl = 'http://175.178.63.53:8000';
