import {FlatList, View} from "react-native";

const RollPicker = () => {

    return (
        <View>

        </View>
    )
}
