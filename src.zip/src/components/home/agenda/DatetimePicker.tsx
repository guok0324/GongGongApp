import React from "react";
import {StyleSheet, View} from "react-native";

const DatetimePicker = () => {



    return (
        <View style={{flex: 1}}>
            <View>

            </View>
            <View>

            </View>
        </View>
    );
}

const ss = StyleSheet.create({
    datetimePickerContainer: {
        flex: 1,
        display: 'flex',
        flexDirection: 'row',
    }
})

export default DatetimePicker;
